﻿namespace CampBg.Common.ShoppingCart.SessionManager
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    using CampBg.Common.ShoppingCart;

    public class CartManager
    {
        private const string SessionSaveKey = "cart";

        private readonly HttpSessionStateBase session;

        public CartManager(HttpSessionStateBase session)
        {
            this.session = session;
        }

        public void AddItem(int productId, int quantity, IEnumerable<KeyValuePair<int, int>> properties)
        {
            var order = (Cart)this.session[SessionSaveKey] ?? new Cart();
            var product =
                order.Items.FirstOrDefault(x =>
                                 x.ProductId == productId
                                 && x.Properties.All(p => properties.Any(
                                     m => m.Key == p.PropertyId && m.Value == p.PropertyValueId)));

            if (quantity != 0)
            {
                if (product != null)
                {
                    order.IncreaseQuantity(product, quantity);
                }
                else
                {
                    order.Add(new CartItem(productId, quantity, properties));
                }
            }

            this.session.Add(SessionSaveKey, order);
        }

        public Cart GetShoppingCart()
        {
            return (Cart)this.session[SessionSaveKey] ?? new Cart();
        }

        public void EmptyCart()
        {
            this.session[SessionSaveKey] = null;
        }
    }
}
