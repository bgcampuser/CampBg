﻿namespace CampBg.Common.ShoppingCart
{
    public class ItemProperty
    {
        public int PropertyId { get; set; }

        public int PropertyValueId { get; set; }
    }
}