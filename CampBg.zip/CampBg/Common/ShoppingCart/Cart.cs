﻿namespace CampBg.Common.ShoppingCart
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Cart
    {
        public Cart()
        {
            this.Items = new HashSet<CartItem>();
        }

        public ICollection<CartItem> Items { get; set; }

        public void Add(CartItem item)
        {
            this.Items.Add(item);
        }

        public void DecreaseQuantity(CartItem item, int quantity)
        {
            item.Quantity -= quantity;
        }

        public void IncreaseQuantity(CartItem item, int quantity)
        {
            item.Quantity += quantity;
        }

        public void Remove(CartItem item)
        {
            this.Items.Remove(item);
        }
    }
}
