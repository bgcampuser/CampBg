﻿namespace CampBg.Data
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;

    using CampBg.Data.Contracts;
    using CampBg.Data.Models;
    using CampBg.Data.Repositories;
    using CampBg.Data.Repositories.Contracts;

    using IUsersRepository = CampBg.Data.Repositories.Contracts.IUsersRepository;

    public class UowData : IUowData
    {
        private readonly DbContext context;

        private readonly Dictionary<Type, object> repositories = new Dictionary<Type, object>();

        public UowData()
            : this(new CampContext())
        {
        }

        public UowData(DbContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context", "Context cannot be null");
            }

            this.context = context;
        }

        public IDeletableRepository<Category> Categories
        {
            get
            {
                return this.GetRepository<Category>();
            }
        }

        public IDeletableRepository<Order> Orders
        {
            get
            {
                return this.GetRepository<Order>();
            }
        }

        public IDeletableRepository<OrderItem> OrderItems
        {
            get
            {
                return this.GetRepository<OrderItem>();
            }
        }

        public IDeletableRepository<Product> Products
        {
            get
            {
                return this.GetRepository<Product>();
            }
        }

        public IDeletableRepository<Manufacturer> Manufacturers
        {
            get
            {
                return this.GetRepository<Manufacturer>();
            }
        }

        public IDeletableRepository<Property> Properties
        {
            get
            {
                return this.GetRepository<Property>();
            }
        }

        public IDeletableRepository<Subcategory> Subcategories
        {
            get
            {
                return this.GetRepository<Subcategory>();
            }
        }

        public IDeletableRepository<SubcategoryOption> SubcategoryOptions
        {
            get
            {
                return this.GetRepository<SubcategoryOption>();
            }
        }

        public IDeletableRepository<SliderImage> SliderImages
        {
            get
            {
                return this.GetRepository<SliderImage>();
            }
        }

        public IDeletableRepository<PropertyValue> PropertyValues
        {
            get
            {
                return this.GetRepository<PropertyValue>();
            }
        }

        public IUsersRepository Users
        {
            get
            {
                return (UsersRepository)this.GetRepository<UserProfile>();
            }
        }

        public int SaveChanges()
        {
            return this.context.SaveChanges();
        }

        public void Dispose()
        {
            this.context.Dispose();
        }

        private IDeletableRepository<T> GetRepository<T>()
            where T : class, IDeletable
        {
            if (!this.repositories.ContainsKey(typeof(T)))
            {
                if (typeof(T).IsAssignableFrom(typeof(UserProfile)))
                {
                    var usersRepository = Activator.CreateInstance(typeof(UsersRepository), this.context);
                    this.repositories.Add(typeof(T), usersRepository);
                }
                else
                {
                    var repository = Activator.CreateInstance(typeof(GenericDeletableRepository<T>), this.context);
                    this.repositories.Add(typeof(T), repository);
                }
            }

            return (IDeletableRepository<T>)this.repositories[typeof(T)];
        }
    }
}
