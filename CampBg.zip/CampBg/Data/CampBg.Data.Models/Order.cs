﻿namespace CampBg.Data.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations.Schema;

    using CampBg.Data.Contracts;

    public class Order : DeletableEntity
    {
        public int Id { get; set; }

        public virtual ICollection<OrderItem> OrderItems { get; set; }

        public UserProfile ByUser { get; set; }

        public bool IsPaid { get; set; }

        public bool IsFinalized { get; set; }

        public bool IsOrdered { get; set; }

        public int DeliveryAddressId { get; set; }

        [ForeignKey("DeliveryAddressId")]
        public DeliveryAddress DeliveryAddress { get; set; }
    }
}