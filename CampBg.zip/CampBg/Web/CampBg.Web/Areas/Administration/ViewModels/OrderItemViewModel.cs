﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using CampBg.Data.Models;

    public class OrderItemViewModel
    {
        public static Func<OrderItem, OrderItemViewModel> FromOrderItem
        {
            get
            {
                return item => new OrderItemViewModel
                {
                    ItemId = item.ProductId,
                    Quantity = item.Quantity,
                    Price = item.Price,
                    Properties = item.PropertyValues.AsQueryable().Select(OrderItemPropertyViewModel.FromPropertyValue)
                };
            }
        }

        public int ItemId { get; set; }

        public int Quantity { get; set; }

        public decimal Price { get; set; }

        public IEnumerable<OrderItemPropertyViewModel> Properties { get; set; }
    }
}