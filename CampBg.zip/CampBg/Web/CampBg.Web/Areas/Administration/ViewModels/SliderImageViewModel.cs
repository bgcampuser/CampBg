﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.Linq.Expressions;

    using CampBg.Data.Models;

    public class SliderImageViewModel
    {
        public static Expression<Func<SliderImage, SliderImageViewModel>> FromSliderImage
        {
            get
            {
                return
                    image =>
                    new SliderImageViewModel
                        {
                            Id = image.Id,
                            Location = image.Location,
                            IsActive = image.IsActive,
                            Name = image.Name
                        };
            }
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public string Location { get; set; }

        public bool IsActive { get; set; }
    }
}