﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.Linq.Expressions;

    using CampBg.Data.Models;

    public class PropertyViewModel
    {
        public static Expression<Func<Property, PropertyViewModel>> FromProperty
        {
            get
            {
                return
                    property => new PropertyViewModel
                    {
                        Name = property.Name,
                        Id = property.Id
                    };
            }
        }

        public int Id { get; set; }

        public string Name { get; set; }
    }
}