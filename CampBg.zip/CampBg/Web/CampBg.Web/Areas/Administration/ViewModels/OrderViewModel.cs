﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;

    using CampBg.Data.Models;

    public class OrderViewModel
    {
        public static Expression<Func<Order, OrderViewModel>> FromOrder
        {
            get
            {
                return
                    order => new OrderViewModel
                    {
                        Id = order.Id,
                        // ByUser = order.ByUser != null ? order.ByUser.UserName : "Anonymous",
                        // Items = order.OrderItems.AsQueryable().Select(OrderItemViewModel.FromOrderItem),
                        MadeOn = order.CreatedOn,
                        IsPaid = order.IsPaid,
                        IsFinalized = order.IsFinalized
                    };
            }
        }

        public int Id { get; set; }

        public string ByUser { get; set; }

        public DateTime MadeOn { get; set; }

        public bool IsPaid { get; set; }

        public bool IsFinalized { get; set; }

        public IEnumerable<OrderItemViewModel> Items { get; set; }
    }
}