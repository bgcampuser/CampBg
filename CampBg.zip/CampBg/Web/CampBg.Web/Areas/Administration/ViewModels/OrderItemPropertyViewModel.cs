﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.Linq.Expressions;

    using CampBg.Data.Models;

    public class OrderItemPropertyViewModel
    {
        public static Expression<Func<PropertyValue, OrderItemPropertyViewModel>> FromPropertyValue
        {
            get
            {
                return pv => new OrderItemPropertyViewModel
                                 {
                                     PropertyId = pv.PropertyId,
                                     PropertyValue = pv.Value,
                                     PropertyValueId = pv.Id,
                                     Property = pv.Property.Name
                                 };
            }
        }

        public int PropertyValueId { get; set; }

        public string PropertyValue { get; set; }

        public int PropertyId { get; set; }

        public string Property { get; set; }
    }
}