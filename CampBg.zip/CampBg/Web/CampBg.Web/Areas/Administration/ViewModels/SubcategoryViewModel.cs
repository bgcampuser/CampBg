﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Linq.Expressions;

    using CampBg.Data.Models;

    public class SubcategoryViewModel
    {
        public static Expression<Func<Subcategory, SubcategoryViewModel>> FromSubcategory
        {
            get
            {
                return
                    propertyCategory => new SubcategoryViewModel
                    {
                        Id = propertyCategory.Id,
                        Name = propertyCategory.Name,
                        CategoryId = propertyCategory.CategoryId
                    };
            }
        }

        public int Id { get; set; }

        public string Name { get; set; }

        [Required]
        public int CategoryId { get; set; }
    }
}