﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Linq.Expressions;

    using CampBg.Data.Models;

    public class ProductViewModel
    {
        public static Expression<Func<Product, ProductViewModel>> FromProduct
        {
            get
            {
                return
                    product =>
                    new ProductViewModel
                        {
                            Id = product.Id,
                            Name = product.Name,
                            Price = product.Price,
                            Description = product.Description,
                            ManufacturerId = product.ManufacturerId,
                            SubcategoryOptionId = product.SubcategoryOptionId,
                            Properties =
                                product.PropertyValues.AsQueryable()
                                .Select(PropertyValueViewModel.FromPropertyValue)
                        };
            }
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }

        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        public int ManufacturerId { get; set; }

        public int SubcategoryOptionId { get; set; }

        public IEnumerable<PropertyValueViewModel> Properties { get; set; }
    }
}