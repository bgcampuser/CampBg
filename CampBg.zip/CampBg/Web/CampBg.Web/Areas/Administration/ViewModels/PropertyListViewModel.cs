﻿namespace CampBg.Web.Areas.Administration.ViewModels
{
    public class PropertyListViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}