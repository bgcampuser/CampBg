﻿namespace CampBg.Web.Areas.Administration.Controllers
{
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;

    using CampBg.Data.Models;
    using CampBg.Web.Areas.Administration.ViewModels;

    using Kendo.Mvc.Extensions;
    using Kendo.Mvc.UI;

    public class ProductsController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            this.ViewBag.Properties = this.Data.Properties.All().Select(x => new
                                                                            {
                                                                                x.Id,
                                                                                x.Name
                                                                            });

            this.ViewBag.Manufacturers = this.Data.Manufacturers.All().Select(x => new
                                                                            {
                                                                                x.Id,
                                                                                x.Name
                                                                            });

            return this.View();
        }

        public ActionResult GetProducts([DataSourceRequest]DataSourceRequest request)
        {
            var products = this.Data.Products.All().Select(ProductViewModel.FromProduct);

            return this.Json(products.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public ActionResult CreateProduct([DataSourceRequest] DataSourceRequest request, ProductViewModel model)
        {
            var products = new List<ProductViewModel>();

            if (this.ModelState.IsValid)
            {
                var product = new Product();
                this.TryUpdateModel(product);
                this.Data.Products.Add(product);
                this.Data.SaveChanges();
            }

            return this.Json(products.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdateProduct([DataSourceRequest] DataSourceRequest request, ProductViewModel model)
        {
            var products = new List<ProductViewModel> { model };

            var product = this.Data.Products.GetById(model.Id);

            if (product == null)
            {
                this.ModelState.AddModelError("Id", "Invalid id was provided");
            }

            if (this.ModelState.IsValid)
            {
                this.TryUpdateModel(product);
                this.Data.SaveChanges();
            }

            return this.Json(products.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteProduct([DataSourceRequest] DataSourceRequest request, ProductViewModel model)
        {
            var products = new List<ProductViewModel>();

            var product = this.Data.Products.GetById(model.Id);
            if (product == null)
            {
                this.ModelState.AddModelError("Id", "Invalid id");
            }

            this.Data.Products.Delete(product);
            this.Data.SaveChanges();

            return this.Json(products.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetProductImages([DataSourceRequest]DataSourceRequest request, int productId)
        {
            var productImages = this.Data.Products.GetById(productId)
                                                    .ProductImages
                                                    .AsQueryable()
                                                    .Select(ProductImageViewModel.FromProductImage);

            return this.Json(productImages.ToDataSourceResult(request), JsonRequestBehavior.AllowGet);
        }

        public ActionResult ReadManufacturers([DataSourceRequest]DataSourceRequest request)
        {
            var manufacturers = this.Data.Manufacturers.All().Select(x => new { x.Id, x.Name });

            return this.Json(manufacturers, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ReadProperties([DataSourceRequest]DataSourceRequest request)
        {
            var manufacturers = this.Data.Properties.All().Select(x => new { x.Id, x.Name });

            return this.Json(manufacturers, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ReadSubcategoryOptions([DataSourceRequest]DataSourceRequest request)
        {
            var results = this.Data.SubcategoryOptions
                .All()
                .Include(x => x.Subcategory)
                .Include(x => x.Subcategory.Category)
                .ToList()
                .Select(x => new
                {
                    x.Id,
                    Name = string.Format("{0} -> {1} -> {2}", x.Subcategory.Category.Name, x.Subcategory.Name, x.Name)
                });

            return this.Json(results, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SaveImages(HttpPostedFileBase image, int id)
        {
            var targetFolderBase = HttpContext.Server.MapPath(string.Format("~/Products/{0}/Images", id));

            if (!Directory.Exists(targetFolderBase))
            {
                Directory.CreateDirectory(targetFolderBase);
            }

            var product = this.Data.Products.GetById(id);

            var savePath = Path.Combine(targetFolderBase, image.FileName);

            var relativeLocation = string.Format("/Products/{0}/Images/{1}", id, image.FileName);
            image.SaveAs(savePath);
            product.ProductImages.Add(new ProductImage
                                          {
                                              Location = relativeLocation,
                                          });

            this.Data.SaveChanges();

            return this.Content(string.Empty);
        }
    }
}