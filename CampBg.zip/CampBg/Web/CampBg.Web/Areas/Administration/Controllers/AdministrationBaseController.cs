﻿namespace CampBg.Web.Areas.Administration.Controllers
{
    using CampBg.Web.Controllers;

    public class AdministrationBaseController : BaseController
    {
    }
}