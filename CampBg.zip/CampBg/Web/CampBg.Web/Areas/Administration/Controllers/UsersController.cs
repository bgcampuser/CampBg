﻿namespace CampBg.Web.Areas.Administration.Controllers
{
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Web.Areas.Administration.ViewModels;

    using Kendo.Mvc.Extensions;
    using Kendo.Mvc.UI;

    public class UsersController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            return this.View();
        }

        public ActionResult Read([DataSourceRequest]DataSourceRequest request)
        {
            var categories = this.Data.Users.All().Select(UserViewModel.FromUserProfile);

            return this.Json(categories.ToDataSourceResult(request));
        }

        public ActionResult Destroy(UserViewModel model)
        {
            var userToDelete = this.Data.Users
                .GetById(model.Id);

            if (userToDelete != null)
            {
                this.Data.Users.Delete(userToDelete);
                this.Data.SaveChanges();
            }

            return this.Json(model, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update(UserViewModel model)
        {
            var userToUpdate = this.Data.Users.GetById(model.Id);

            this.TryUpdateModel(userToUpdate);
            this.Data.SaveChanges();

            return this.Json(model, JsonRequestBehavior.AllowGet);
        }
    }
}