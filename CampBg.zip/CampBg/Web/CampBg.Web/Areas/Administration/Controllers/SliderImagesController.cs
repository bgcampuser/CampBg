﻿namespace CampBg.Web.Areas.Administration.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Data.Models;
    using CampBg.Web.Areas.Administration.ViewModels;

    using Kendo.Mvc.Extensions;
    using Kendo.Mvc.UI;

    public class SliderImagesController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            return this.View();
        }

        public ActionResult GetImages([DataSourceRequest]DataSourceRequest request)
        {
            var categories = this.Data.SliderImages.All().Select(SliderImageViewModel.FromSliderImage);

            return this.Json(categories.ToDataSourceResult(request));
        }

        public ActionResult CreateImage(SliderImageViewModel model)
        {
            var result = new List<SliderImageViewModel> { model };
            if (this.ModelState.IsValid)
            {
                var sliderImage = new SliderImage();
                this.TryUpdateModel(sliderImage);

                this.Data.SliderImages.Add(sliderImage);
                this.Data.SaveChanges();

                model.Id = sliderImage.Id;
            }

            return this.Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteImage(SliderImageViewModel model)
        {
            var imageToDelete = this.Data.SliderImages.GetById(model.Id);

            if (imageToDelete != null)
            {
                this.Data.SliderImages.Delete(imageToDelete);
                this.Data.SaveChanges();
            }

            return this.Json(model, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UpdateImage(SliderImageViewModel model)
        {
            var sliderImage = this.Data.SliderImages.GetById(model.Id);

            this.TryUpdateModel(sliderImage);
            this.Data.SaveChanges();

            return this.Json(model, JsonRequestBehavior.AllowGet);
        }
    }
}