﻿namespace CampBg.Web.Areas.Administration.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Data.Models;
    using CampBg.Web.Areas.Administration.ViewModels;

    using Kendo.Mvc.Extensions;
    using Kendo.Mvc.UI;

    public class ManufacturersController : AdministrationBaseController
    {
        public ActionResult Index()
        {
            return this.View();
        }

        public ActionResult Read([DataSourceRequest]DataSourceRequest request)
        {
            var categories = this.Data.Manufacturers.All().Select(ManufacturerViewModel.FromManufacturer);

            return this.Json(categories.ToDataSourceResult(request));
        }

        public ActionResult Create(ManufacturerViewModel model)
        {
            var result = new List<ManufacturerViewModel> { model };
            if (this.ModelState.IsValid)
            {
                var manufacturer = new Manufacturer();

                this.TryUpdateModel(manufacturer);

                this.Data.Manufacturers.Add(manufacturer);
                this.Data.SaveChanges();

                model.Id = manufacturer.Id;
            }

            return this.Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Destroy(ManufacturerViewModel model)
        {
            var manufacturerToDelete = this.Data.Manufacturers
                .GetById(model.Id);

            if (manufacturerToDelete != null)
            {
                this.Data.Manufacturers.Delete(manufacturerToDelete);
                this.Data.SaveChanges();
            }

            return this.Json(model, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update(ManufacturerViewModel model)
        {
            var manufacturerToUpdate = this.Data.Manufacturers.GetById(model.Id);

            this.TryUpdateModel(manufacturerToUpdate);
            this.Data.SaveChanges();

            return this.Json(model, JsonRequestBehavior.AllowGet);
        }
    }
}