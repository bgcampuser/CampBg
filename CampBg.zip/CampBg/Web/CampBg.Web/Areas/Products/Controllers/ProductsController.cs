﻿namespace CampBg.Web.Areas.Products.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Data.Models;
    using CampBg.Extensions;
    using CampBg.Web.Areas.Products.ViewModels;
    using CampBg.Web.Controllers;
    using CampBg.Web.ViewModels;

    using Kendo.Mvc.Extensions;

    public class ProductsController : BaseController
    {
        private const int PageSize = 24;

        public ActionResult Details(int id, string name)
        {
            var product = this.Data.Products.All()
                                            .Where(prod => prod.Id == id)
                                            .Select(ProductDetailsViewModel.FromProduct)
                                            .FirstOrDefault();

            return this.View(product);
        }

        public ActionResult BySubcategory(string name, string category)
        {
            var products =
                this.Data.Products.All()
                    .Where(
                        x =>
                        x.SubcategoryOption.Subcategory.Name == name
                        && x.SubcategoryOption.Subcategory.Category.Name == category);

            var model = new FilterPageViewModel
                            {
                                InitialProducts =
                                    this.GetProductsInSubcategory(name, category)
                                    .Select(ProductListViewModel.FromProduct),
                                Filters = new FilterContainerViewModel()
                            };

            model.Filters.PropertyFilter =
                products.SelectMany(x => x.PropertyValues)
                    .GroupBy(x => x.Property)
                    .Select(
                        x =>
                        new ProductPropertyViewModel
                            {
                                Name = x.Key.Name,
                                PropertyId = x.Key.Id,
                                Values =
                                    x.Distinct()
                                    .OrderBy(v => v.Value)
                                    .Select(
                                        z =>
                                        new PropertyValueViewModel
                                            {
                                                Id = z.Id,
                                                Value = z.Value
                                            })
                            })
                    .ToList();

            model.Filters.ManufacturerFilter =
                this.Data.Manufacturers.All()
                    .Where(
                        x =>
                        !x.IsDeleted
                        && x.Products.Any(
                            z =>
                            z.SubcategoryOption.Subcategory.Category.Name == category
                            && z.SubcategoryOption.Subcategory.Name == name))
                    .Select(ManufacturerViewModel.FromManufacturer);

            model.Filters.PriceFilter = new PriceViewModel
                                            {
                                                Maximum =
                                                    this.Data.Products.All()
                                                    .Where(
                                                        x =>
                                                        x.SubcategoryOption.Subcategory.Name == name
                                                        && x.SubcategoryOption.Subcategory.Category.Name
                                                        == category)
                                                    .Max(z => z.Price),
                                                Minimum =
                                                    this.Data.Products.All()
                                                    .Where(
                                                        x =>
                                                        x.SubcategoryOption.Subcategory.Name == name
                                                        && x.SubcategoryOption.Subcategory.Category.Name
                                                        == category)
                                                    .Min(z => z.Price),
                                            };

            return this.View(model);
        }

        ////public ActionResult BySubcategoryOption(string category, string subcategory, string name)
        ////{
        ////    var productsInSubcategory =
        ////       this.Data.Products.All()
        ////           .Where(
        ////               x =>
        ////                x.SubcategoryOption.Name == name &&
        ////                x.SubcategoryOption.Subcategory.Name == subcategory
        ////                && x.SubcategoryOption.Subcategory.Category.Name == category)
        ////                .Select(ProductListViewModel.FromProduct);

        ////    return this.View(productsInSubcategory);
        ////}

        public ActionResult Filter(FilterViewModel filter, string name, string category)
        {
            var productsToFilter = this.GetProductsInSubcategory(name, category);
            var filterResult = this.ApplyFiltering(productsToFilter, filter);

            var filterResultViewModel = filterResult.Select(ProductListViewModel.FromProduct);

            return this.PartialView("FilterResult", filterResultViewModel);
        }

        public ActionResult Search(string q, int page = 0)
        {
            var searchResults =
                this.Data.Products.All()
                    .AsQueryable()
                    .Where(x => !x.IsDeleted && (x.Name.Contains(q) || x.Description.Contains(q)))
                    .OrderBy(x => x.CreatedOn)
                    .Select(ProductListViewModel.FromProduct)
                    .Skip(page * PageSize)
                    .Take(PageSize);

            return this.View(searchResults);
        }

        private IQueryable<Product> GetProductsInSubcategory(string name, string category)
        {
            var result = this.Data.Products.All()
                .Where(x =>
                    x.SubcategoryOption.Subcategory.Name == name
                    && x.SubcategoryOption.Subcategory.Category.Name == category);

            return result;
        }

        private IQueryable<Product> ApplyFiltering(IQueryable<Product> products, FilterViewModel filter)
        {
            if (filter.Manufacturers.Any())
            {
                products =
                    products.Where(
                        LinqBuilder.BuildOrExpression<Product, int>(x => x.ManufacturerId, filter.Manufacturers));
            }

            var groupedFilters = filter.SelectedProperties.GroupBy(x => x.PropertyId);

            products = this.ProcessFilterGroup(products, groupedFilters);

            return products;
        }

        private IQueryable<Product> ProcessFilterGroup(
            IQueryable<Product> products,
            IEnumerable<IGrouping<int, PropertyValueViewModel>> groupedFilters)
        {
            foreach (var groupedFilter in groupedFilters)
            {
                var intersection =
                    this.Data.PropertyValues.All()
                        .Where(
                            LinqBuilder.BuildOrExpression<PropertyValue, int>(
                                x => x.Id,
                                groupedFilter.Select(x => x.Id)))
                        .SelectMany(x => x.Products);

                products = products.Intersect(intersection);
            }

            return products;
        }
    }
}