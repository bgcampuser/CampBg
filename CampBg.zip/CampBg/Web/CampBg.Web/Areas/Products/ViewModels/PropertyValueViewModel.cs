﻿namespace CampBg.Web.Areas.Products.ViewModels
{
    public class PropertyValueViewModel
    {
        public int Id { get; set; }

        public string Value { get; set; }

        public int PropertyId { get; set; }
    }
}