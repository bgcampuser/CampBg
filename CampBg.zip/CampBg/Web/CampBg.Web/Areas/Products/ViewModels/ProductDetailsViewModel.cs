﻿namespace CampBg.Web.Areas.Products.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;

    using CampBg.Data.Models;
    using CampBg.Web.ViewModels;

    using Resources;

    public class ProductDetailsViewModel
    {
        public static Expression<Func<Product, ProductDetailsViewModel>> FromProduct
        {
            get
            {
                return prod => new ProductDetailsViewModel
                                   {
                                       Id = prod.Id,
                                       Name = prod.Name,
                                       Price = prod.Price,
                                       Description = prod.Description,
                                       Images = prod.ProductImages
                                                   .Where(x => !x.IsDeleted)
                                                   .AsQueryable()
                                                   .Select(ProductImageViewModel.FromProductImage),
                                       Properties = prod.PropertyValues
                                                   .Where(x => !x.IsDeleted)
                                                   .AsQueryable()
                                                   .GroupBy(x => x.Property)
                                                   .Select(x => new ProductPropertyViewModel
                                                                   {
                                                                       PropertyId = x.Key.Id,
                                                                       Name = x.Key.Name,
                                                                       Values = x.Select(v => new PropertyValueViewModel
                                                                                                {
                                                                                                    Id = v.Id,
                                                                                                    Value = v.Value
                                                                                                })
                                                                   }),
                                       Manufacturer = prod.Manufacturer.Name
                                   };
            }
        }

        public int Id { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }

        public string Description { get; set; }

        public string Manufacturer { get; set; }

        public IEnumerable<ProductImageViewModel> Images { get; set; }

        public IEnumerable<ProductPropertyViewModel> Properties { get; set; }

        public IEnumerable<ProductListViewModel> SimilarProducts { get; set; }

        public string DefaultImageLocation
        {
            get
            {
                var defaultImage = this.Images.FirstOrDefault(img => img.IsDefault);

                if (defaultImage != null)
                {
                    return defaultImage.Location;
                }

                var firstImage = this.Images.FirstOrDefault();

                return firstImage == null ? GlobalConstants.PlaceholderImage : firstImage.Location;
            }
        }
    }
}