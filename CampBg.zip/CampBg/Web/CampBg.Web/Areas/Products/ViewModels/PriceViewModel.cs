﻿namespace CampBg.Web.Areas.Products.ViewModels
{
    public class PriceViewModel
    {
        public decimal Minimum { get; set; }

        public decimal Maximum { get; set; }
    }
}