﻿namespace CampBg.Web.Areas.Products.ViewModels
{
    using System.Collections.Generic;

    public class FilterViewModel
    {
        public FilterViewModel()
        {
            this.Manufacturers = new HashSet<int>();
            this.SelectedProperties = new HashSet<PropertyValueViewModel>();
        }

        public IEnumerable<int> Manufacturers { get; set; }

        public IEnumerable<PropertyValueViewModel> SelectedProperties { get; set; }
    }
}