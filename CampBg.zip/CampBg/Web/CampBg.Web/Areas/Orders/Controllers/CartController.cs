﻿namespace CampBg.Web.Areas.Orders.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Common.ShoppingCart.SessionManager;
    using CampBg.Web.Areas.Orders.InputModels;
    using CampBg.Web.Areas.Orders.ViewModels;
    using CampBg.Web.Controllers;

    public class CartController : BaseController
    {
        public ActionResult Index()
        {
            var cartManager = new CartManager(this.HttpContext.Session);
            var shoppingCart = cartManager.GetShoppingCart();
            var items = shoppingCart.Items;

            var cartViewModel = new CartViewModel(items);

            return this.View(cartViewModel);
        }

        [HttpPost]
        public ActionResult AddToCart(ProductCartInputModel model)
        {
            var httpSessionStateBase = this.HttpContext.Session;

            if (httpSessionStateBase == null)
            {
                throw new ArgumentNullException();
            }

            var sessionManager = new CartManager(httpSessionStateBase);

            IEnumerable<KeyValuePair<int, int>> properties = model.SelectedProperties != null
                                                                 ? model.SelectedProperties.Select(
                                                                     x =>
                                                                     new KeyValuePair<int, int>(
                                                                         x.PropertyId,
                                                                         x.PropertyValueId))
                                                                 : new HashSet<KeyValuePair<int, int>>();

            sessionManager.AddItem(model.ProductId, model.Quantity, properties);

            return this.Json("Success");
        }

        [HttpPost]
        public ActionResult RemoveFromCart()
        {
            return this.Json("Success");
        }

        public ActionResult Confirm()
        {
            var cartManager = new CartManager(this.HttpContext.Session);
            var shoppingCart = cartManager.GetShoppingCart();
            var items = shoppingCart.Items;

            var orderConfirmationViewModel = new OrderConfirmationViewModel { Cart = new CartViewModel(items) };

            return this.View(orderConfirmationViewModel);
        }
    }
}