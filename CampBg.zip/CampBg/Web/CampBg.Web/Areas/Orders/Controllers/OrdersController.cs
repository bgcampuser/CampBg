﻿namespace CampBg.Web.Areas.Orders.Controllers
{
    using System.Data.Entity;
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Common.ShoppingCart.SessionManager;
    using CampBg.Data.Models;
    using CampBg.Extensions;
    using CampBg.Web.Areas.Orders.ViewModels;
    using CampBg.Web.Controllers;

    public class OrdersController : BaseController
    {
        public ActionResult Index()
        {
            if (this.User.Identity.IsAuthenticated)
            {
                return this.View();
            }
            else
            {
                return this.RedirectToAction("Login", "Account", new { area = string.Empty });
            }
        }

        [HttpPost]
        public ActionResult Place(OrderViewModel model)
        {
            var httpSessionStateBase = this.HttpContext.Session;
            var cartManager = new CartManager(httpSessionStateBase);
            var shoppingCart = cartManager.GetShoppingCart();

            var products =
                this.Data.Products.All()
                    .Include(x => x.PropertyValues)
                    .Where(
                        LinqBuilder.BuildOrExpression<Product, int>(
                            x => x.Id,
                            shoppingCart.Items.Select(x => x.ProductId)))
                    .ToList();

            var order = new Order
                            {
                                OrderItems = shoppingCart.Items.Select(
                                    oi =>
                                    {
                                        var product = products.First(pr => pr.Id == oi.ProductId);
                                        var orderItem = new OrderItem
                                                            {
                                                                ProductId = oi.ProductId,
                                                                Price = product.Price,
                                                                Quantity = oi.Quantity,
                                                                PropertyValues =
                                                                    product.PropertyValues.Where(
                                                                        pv =>
                                                                        oi.Properties.Any(prop => prop.PropertyValueId == pv.Id))
                                                                    .ToList()
                                                            };
                                        return orderItem;
                                    }).ToList(),
                                ByUser = this.UserProfile
                            };

            if (model.AddressId != null)
            {
                order.DeliveryAddressId = model.AddressId.Value;
            }
            else
            {
                order.DeliveryAddress = new DeliveryAddress
                                            {
                                                Address = model.Address
                                            };
            }

            this.Data.Orders.Add(order);
            this.Data.SaveChanges();

            cartManager.EmptyCart();

            return this.RedirectToAction("Confirmed");
        }

        public ActionResult Confirmed()
        {
            return this.View();
        }
    }
}