namespace CampBg.Web.Areas.Orders.InputModels
{
    public class PropertyValueInputModel
    {
        public int PropertyId { get; set; }

        public int PropertyValueId { get; set; }
    }
}