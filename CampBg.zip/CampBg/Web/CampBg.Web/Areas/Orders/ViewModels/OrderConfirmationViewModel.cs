﻿namespace CampBg.Web.Areas.Orders.ViewModels
{
    public class OrderConfirmationViewModel : OrderViewModel
    {
        public CartViewModel Cart { get; set; }
    }
}