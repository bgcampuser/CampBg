﻿namespace CampBg.Web.Areas.Orders.ViewModels
{
    public class OrderViewModel
    {
        public int? AddressId { get; set; }

        public string Address { get; set; }
    }
}