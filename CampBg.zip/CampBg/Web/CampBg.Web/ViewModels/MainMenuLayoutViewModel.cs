﻿namespace CampBg.Web.ViewModels
{
    using System.Collections.Generic;

    public class MainMenuLayoutViewModel
    {
        public IEnumerable<CategoryViewModel> Categories { get; set; }
    }
}