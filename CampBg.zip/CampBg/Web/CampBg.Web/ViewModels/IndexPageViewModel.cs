﻿namespace CampBg.Web.ViewModels
{
    using System.Collections.Generic;

    using CampBg.Web.Areas.Administration.ViewModels;
    using CampBg.Web.Areas.Products.ViewModels;

    public class IndexPageViewModel
    {
        public IndexPageViewModel()
        {
            this.LatestProducts = new HashSet<ProductListViewModel>();
            this.PopularProducts = new HashSet<ProductListViewModel>();
            this.SliderImages = new HashSet<SliderImageViewModel>();
        }

        public IEnumerable<ProductListViewModel> LatestProducts { get; set; }

        public IEnumerable<ProductListViewModel> PopularProducts { get; set; }

        public IEnumerable<SliderImageViewModel> SliderImages { get; set; }
    }
}