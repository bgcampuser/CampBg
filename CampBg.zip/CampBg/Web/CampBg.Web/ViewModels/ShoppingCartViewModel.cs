﻿namespace CampBg.Web.ViewModels
{
    public class ShoppingCartMenuViewModel
    {
        public decimal Total { get; set; }

        public int ProductCount { get; set; }
    }
}