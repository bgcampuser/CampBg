﻿namespace CampBg.Web.Controllers
{
    using System;
    using System.Linq;
    using System.Web.Mvc;
    using System.Web.Routing;

    using CampBg.Common.ShoppingCart.SessionManager;
    using CampBg.Data;
    using CampBg.Data.Models;
    using CampBg.Data.Repositories.Contracts;
    using CampBg.Extensions;
    using CampBg.Web.ViewModels;

    public abstract class BaseController : Controller
    {
        protected readonly IUowData Data;

        protected BaseController()
            : this(new UowData())
        {
        }

        protected BaseController(IUowData data)
        {
            this.Data = data;
        }

        protected UserProfile UserProfile { get; private set; }

        protected override IAsyncResult BeginExecute(RequestContext requestContext, AsyncCallback callback, object state)
        {
            this.ViewBag.MainMenu = new MainMenuLayoutViewModel
            {
                Categories = this.Data.Categories.All().Where(x => !x.IsDeleted).Select(CategoryViewModel.FromCategory)
            };

            this.UserProfile = this.Data.Users.GetByUsername(requestContext.HttpContext.User.Identity.Name);

            var httpSessionStateBase = requestContext.HttpContext.Session;
            var cartManager = new CartManager(httpSessionStateBase);
            var shoppingCart = cartManager.GetShoppingCart();

            ShoppingCartMenuViewModel cart;

            if (shoppingCart == null)
            {
                cart = new ShoppingCartMenuViewModel { Total = 0, ProductCount = 0 };
            }
            else
            {
                cart = new ShoppingCartMenuViewModel
                           {
                               Total =
                                   this.Data.Products.All()
                                   .Where(LinqBuilder.BuildOrExpression<Product, int>(x => x.Id, shoppingCart.Items.Select(z => z.ProductId)))
                                   .Select(
                                       x => new { x.Id, x.Price })
                                   .ToList()
                                   .Sum(x => x.Price * shoppingCart.Items.Where(z => z.ProductId == x.Id).Sum(c => c.Quantity)),
                               ProductCount = shoppingCart.Items.Sum(x => x.Quantity)
                           };
            }

            this.ViewBag.Cart = cart;

            return base.BeginExecute(requestContext, callback, state);
        }
    }
}