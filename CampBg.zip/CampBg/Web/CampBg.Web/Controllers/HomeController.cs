﻿namespace CampBg.Web.Controllers
{
    using System.Linq;
    using System.Web.Mvc;

    using CampBg.Web.Areas.Administration.ViewModels;
    using CampBg.Web.Areas.Products.ViewModels;
    using CampBg.Web.ViewModels;

    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            var indexViewModel = new IndexPageViewModel
                                     {
                                         LatestProducts =
                                             this.Data.Products.All()
                                             .OrderByDescending(product => product.CreatedOn)
                                             .Take(6)
                                             .Select(ProductListViewModel.FromProduct),
                                         PopularProducts =
                                             this.Data.Products.All()
                                             .Take(6)
                                             .AsQueryable()
                                             .Select(ProductListViewModel.FromProduct),
                                         SliderImages =
                                             this.Data.SliderImages.All()
                                             .Where(img => img.IsActive)
                                             .Select(SliderImageViewModel.FromSliderImage)
                                     };

            return this.View(indexViewModel);
        }
    }
}