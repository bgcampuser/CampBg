Name:       Koloria Icons Pack
Icons:      160+
Size:       32x32 pixels

Author:     Andy Gongea
URL:        http://graphicrating.com
Description:
I designed Koloria in order to cover as many needs as possible. Whether you want to use it in a product website, a portfolio or even a webapp, these icons will help you achieve your goals.
I am available for work, please contact me using Graphic Rating's contact form or social media (Twitter/Facebook).
